import Server from '@fullstacked/webapp/server';

const server = new Server();

export default server.serverHTTP;

server.start();
